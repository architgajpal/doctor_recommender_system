import servicesJava.NewDoctorRatingTRD;

public class TestClass2 {

	public static void main(String[] args)
	{
		//System.out.println("Received id:"+id);
		new NewDoctorRatingTRD().updateRatingTRD(119);

	}
}
